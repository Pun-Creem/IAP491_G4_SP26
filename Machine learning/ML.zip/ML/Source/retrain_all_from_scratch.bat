@echo off
setlocal

REM Run from repo root: D:\Đồ án\report\cape_vt_similarity\cape_vt_similarity

python src\00_build_meta_auto.py --reports-dir "D:\Đồ án\report\943_filtered\943_filtered" --allowed-malstatus malicious suspicious
if errorlevel 1 goto :fail

python src\01_build_samples_from_cape_vt.py --meta-csv data\raw\meta_auto.csv --vt-xlsx "D:\Đồ án\report\TTP_MBC_VirusTotal.xlsx"
if errorlevel 1 goto :fail

python src\02_fit_text_encoder.py
if errorlevel 1 goto :fail

python src\03_build_pairs.py
if errorlevel 1 goto :fail

python src\04_train_similarity.py --model logistic
if errorlevel 1 goto :fail

python src\05_eval_top5.py --model-path models\similarity_model_logistic.joblib
if errorlevel 1 goto :fail

python src\04_train_similarity.py --model xgboost
if errorlevel 1 goto :fail

python src\05_eval_top5.py --model-path models\similarity_model_xgboost.joblib
if errorlevel 1 goto :fail

python src\04_train_similarity.py --model random_forest
if errorlevel 1 goto :fail

python src\05_eval_top5.py --model-path models\similarity_model_random_forest.joblib
if errorlevel 1 goto :fail

python src\07_compare_models.py
if errorlevel 1 goto :fail

echo Done.
goto :eof

:fail
echo Pipeline failed.
exit /b 1
