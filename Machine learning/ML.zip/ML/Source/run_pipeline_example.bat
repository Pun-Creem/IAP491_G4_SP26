@echo off
REM ============================
REM EDIT THESE 2 PATHS FIRST
REM ============================
set REPORTS_DIR=D:\Do an\report\943_filtered\943_filtered
set VT_XLSX=D:\Do an\TTP_MBC_VirusTotal.xlsx

python src\00_build_meta_auto.py --reports-dir "%REPORTS_DIR%" --out-meta data\raw\meta_auto.csv --out-dropped data\raw\meta_dropped.csv
python src\01_build_samples_from_cape_vt.py --meta-csv data\raw\meta_auto.csv --vt-xlsx "%VT_XLSX%"
python src\02_fit_text_encoder.py
python src\03_build_pairs.py

python src\04_train_similarity.py --model logistic
python src\05_eval_top5.py --model-path models\similarity_model_logistic.joblib

python src\04_train_similarity.py --model xgboost
python src\05_eval_top5.py --model-path models\similarity_model_xgboost.joblib

python src\07_compare_models.py

pause
