from __future__ import annotations

import json
import logging
import os
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import joblib
import numpy as np
import pandas as pd


TOKEN_SPLIT = "|"
DEFAULT_SIGNATURE_PARENT_DEPTH = 3

ATTACK_RE = re.compile(r"\bT\d{4}(?:\.\d{3})?\b", flags=re.IGNORECASE)
MBC_RE = re.compile(r"\b[A-Z]{1,3}\d{4}(?:\.[A-Za-z0-9]+)?\b", flags=re.IGNORECASE)
SHA256_RE = re.compile(r"\b[a-fA-F0-9]{64}\b")
ATTACK_PARENT_RE = re.compile(r"^(T\d{4})$", flags=re.IGNORECASE)
MBC_PARENT_RE = re.compile(r"^([A-Z]{1,3}\d{4})$", flags=re.IGNORECASE)


# ---------------------------
# Logging helpers
# ---------------------------
def _safe_name(value: Any, fallback: str = "run") -> str:
    text = "" if value is None else str(value).strip()
    if not text:
        text = fallback
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("._")
    return text or fallback


def build_run_log_path(script_name: str, log_file: str | Path | None = None) -> Path:
    """
    Create a unique txt log path for each run.

    Rules:
    - None / empty -> logs/<script_name>_<timestamp>_<pid>.txt
    - existing directory -> <dir>/<script_name>_<timestamp>_<pid>.txt
    - path ending with .txt -> <parent>/<stem>_<timestamp>_<pid>.txt
    - path with no suffix -> treat as directory and create a unique file inside it
    """
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    pid = os.getpid()
    safe_script = _safe_name(script_name, fallback="run")

    if log_file is None or str(log_file).strip() == "":
        base_dir = Path("logs")
        base_dir.mkdir(parents=True, exist_ok=True)
        return base_dir / f"{safe_script}_{timestamp}_{pid}.txt"

    path = Path(log_file)

    if path.exists() and path.is_dir():
        path.mkdir(parents=True, exist_ok=True)
        return path / f"{safe_script}_{timestamp}_{pid}.txt"

    if path.suffix.lower() == ".txt":
        path.parent.mkdir(parents=True, exist_ok=True)
        stem = _safe_name(path.stem or safe_script, fallback=safe_script)
        return path.parent / f"{stem}_{timestamp}_{pid}.txt"

    if path.suffix == "":
        path.mkdir(parents=True, exist_ok=True)
        return path / f"{safe_script}_{timestamp}_{pid}.txt"

    path.parent.mkdir(parents=True, exist_ok=True)
    stem = _safe_name(path.stem or safe_script, fallback=safe_script)
    return path.parent / f"{stem}_{timestamp}_{pid}.txt"


def setup_logger(script_name: str, log_file: str | Path | None = None) -> logging.Logger:
    log_path = build_run_log_path(script_name, log_file=log_file)
    logger_name = f"pipeline.{_safe_name(script_name)}.{log_path.stem}"
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.INFO)
    logger.propagate = False

    if logger.handlers:
        for handler in list(logger.handlers):
            logger.removeHandler(handler)
            try:
                handler.close()
            except Exception:
                pass

    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s")

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.INFO)
    file_handler.setFormatter(formatter)

    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(logging.INFO)
    stream_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)
    setattr(logger, "_log_path", str(log_path))

    logger.info("=" * 100)
    logger.info("START %s | log_file=%s", script_name, log_path)
    return logger


def get_logger_log_path(logger: logging.Logger) -> str:
    return str(getattr(logger, "_log_path", ""))


def log_exception(logger: logging.Logger, message: str, exc: Exception) -> None:
    logger.exception("%s | error=%s", message, exc)


# ---------------------------
# Generic helpers
# ---------------------------
def load_json(path: str | Path) -> Dict[str, Any]:
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def normalize_token(token: Any) -> str:
    if token is None:
        return ""
    token = str(token).strip().lower()
    token = re.sub(r"[^a-z0-9_:\.-]+", "_", token)
    token = re.sub(r"_+", "_", token).strip("_")
    return token


def normalize_sha256(value: Any) -> str:
    return extract_sha256(value)


def split_signature_parts(value: Any) -> List[str]:
    token = normalize_token(value)
    if not token:
        return []
    return [part for part in token.split("_") if part]


def collapse_signature_name(value: Any, parent_depth: int = DEFAULT_SIGNATURE_PARENT_DEPTH) -> str:
    parts = split_signature_parts(value)
    if not parts:
        return ""
    depth = max(1, int(parent_depth))
    if len(parts) <= depth:
        return "_".join(parts)
    return "_".join(parts[:depth])


def collapse_signature_names(values: Iterable[Any], parent_depth: int = DEFAULT_SIGNATURE_PARENT_DEPTH) -> Set[str]:
    out: Set[str] = set()
    for value in values:
        token = collapse_signature_name(value, parent_depth=parent_depth)
        if token:
            out.add(token)
    return out


def set_to_pipe(values: Iterable[str]) -> str:
    vals = sorted({str(v).strip() for v in values if str(v).strip()})
    return TOKEN_SPLIT.join(vals)


def pipe_to_set(value: Any) -> Set[str]:
    if value is None:
        return set()
    if isinstance(value, float) and pd.isna(value):
        return set()
    if isinstance(value, set):
        return {str(v).strip() for v in value if str(v).strip()}
    if isinstance(value, (list, tuple)):
        return {str(v).strip() for v in value if str(v).strip()}
    value = str(value).strip()
    if not value:
        return set()
    return {v.strip() for v in value.split(TOKEN_SPLIT) if v.strip()}


def normalize_family_label(value: Any) -> str:
    if value is None:
        return ""
    value = str(value).strip()
    if not value:
        return ""
    value = re.sub(r"[^A-Za-z0-9]+", "_", value)
    value = re.sub(r"_+", "_", value).strip("_")
    return value.lower()


def choose_family(report: Dict[str, Any]) -> Tuple[str, str]:
    families_raw: List[str] = []

    for det in report.get("detections", []) or []:
        fam = det.get("family")
        if fam:
            families_raw.append(str(fam).strip())

    if not families_raw:
        for item in ((report.get("target", {}) or {}).get("file", {}) or {}).get("cape_yara", []) or []:
            name = item.get("name")
            if name:
                families_raw.append(str(name).strip())

    if not families_raw:
        cape_type = ((report.get("target", {}) or {}).get("file", {}) or {}).get("cape_type", "")
        if cape_type:
            families_raw.append(str(cape_type).strip())

    families_raw = [f for f in families_raw if f]
    family_raw = families_raw[0] if families_raw else ""
    family = normalize_family_label(family_raw)
    return family, family_raw


def flatten_strings(obj: Any, limit: Optional[int] = None) -> List[str]:
    out: List[str] = []

    def _walk(x: Any) -> None:
        nonlocal out
        if limit is not None and len(out) >= limit:
            return
        if x is None:
            return
        if isinstance(x, str):
            s = x.strip()
            if s:
                out.append(s)
            return
        if isinstance(x, dict):
            for v in x.values():
                _walk(v)
                if limit is not None and len(out) >= limit:
                    return
            return
        if isinstance(x, (list, tuple, set)):
            for item in x:
                _walk(item)
                if limit is not None and len(out) >= limit:
                    return

    _walk(obj)
    return out


# ---------------------------
# ATT&CK / MBC normalization
# ---------------------------
def extract_attack_ids(text: Any) -> Set[str]:
    if text is None:
        return set()
    s = " ".join(flatten_strings(text))
    return {m.group(0).upper() for m in ATTACK_RE.finditer(s)}


def extract_mbc_ids(text: Any) -> Set[str]:
    if text is None:
        return set()
    s = " ".join(flatten_strings(text))
    out = {m.group(0).upper() for m in MBC_RE.finditer(s)}
    return {x for x in out if not ATTACK_RE.fullmatch(x)}


def collapse_attack_id(value: Any) -> str:
    if value is None:
        return ""
    value = str(value).strip().upper()
    m = ATTACK_RE.search(value)
    if not m:
        return ""
    token = m.group(0).upper().split(".")[0]
    return token if ATTACK_PARENT_RE.fullmatch(token) else ""


def collapse_mbc_id(value: Any) -> str:
    if value is None:
        return ""
    value = str(value).strip().upper()
    m = MBC_RE.search(value)
    if not m:
        return ""
    token = m.group(0).upper().split(".")[0]
    if ATTACK_RE.fullmatch(token):
        return ""
    return token if MBC_PARENT_RE.fullmatch(token) else ""


def collapse_attack_ids(values: Iterable[Any]) -> Set[str]:
    out: Set[str] = set()
    for value in values:
        token = collapse_attack_id(value)
        if token:
            out.add(token)
    return out


def collapse_mbc_ids(values: Iterable[Any]) -> Set[str]:
    out: Set[str] = set()
    for value in values:
        token = collapse_mbc_id(value)
        if token:
            out.add(token)
    return out


def extract_sha256(value: Any) -> str:
    if value is None:
        return ""
    s = str(value).strip()
    m = SHA256_RE.search(s)
    return m.group(0).lower() if m else ""


def find_best_column(columns: Sequence[str], targets: Sequence[str]) -> Optional[str]:
    norm_map = {c: re.sub(r"[^a-z0-9]+", "", str(c).lower()) for c in columns}

    for target in targets:
        target_norm = re.sub(r"[^a-z0-9]+", "", target.lower())
        for c, n in norm_map.items():
            if n == target_norm:
                return c

    for target in targets:
        target_norm = re.sub(r"[^a-z0-9]+", "", target.lower())
        for c, n in norm_map.items():
            if target_norm in n or n in target_norm:
                return c
    return None


# ---------------------------
# VT workbook readers
# ---------------------------
def read_vt_excel(path: Optional[str | Path]) -> Dict[str, Dict[str, Set[str]]]:
    if path is None:
        return {}

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"VT Excel not found: {path}")

    all_sheets = pd.read_excel(path, sheet_name=None, dtype=str)
    merged: Dict[str, Dict[str, Set[str]]] = {}

    for _, df in all_sheets.items():
        if df is None or df.empty:
            continue

        df = df.copy()
        df.columns = [str(c).strip() for c in df.columns]

        sha_col = find_best_column(df.columns, ["sha256", "sha_256", "hash", "sha2"])
        ttp_col = find_best_column(df.columns, ["technique id", "techniqueid", "ttp", "attack", "mitre"])
        mbc_col = find_best_column(df.columns, ["mbc", "mbcs"])

        if sha_col is None:
            continue

        df[sha_col] = df[sha_col].ffill()

        for _, row in df.iterrows():
            sha = extract_sha256(row.get(sha_col))
            if not sha:
                continue

            ttp_vals_raw: Set[str] = set()
            mbc_vals_raw: Set[str] = set()

            if ttp_col is not None:
                ttp_vals_raw |= extract_attack_ids(row.get(ttp_col))
            if mbc_col is not None:
                mbc_vals_raw |= extract_mbc_ids(row.get(mbc_col))

            row_text = " ".join(
                "" if row.get(col) is None else str(row.get(col))
                for col in df.columns
                if col != sha_col
            )
            ttp_vals_raw |= extract_attack_ids(row_text)
            mbc_vals_raw |= extract_mbc_ids(row_text)

            merged.setdefault(
                sha,
                {
                    "ttps": set(),
                    "mbcs": set(),
                    "ttps_raw": set(),
                    "mbcs_raw": set(),
                },
            )
            merged[sha]["ttps_raw"].update(ttp_vals_raw)
            merged[sha]["mbcs_raw"].update(mbc_vals_raw)
            merged[sha]["ttps"].update(collapse_attack_ids(ttp_vals_raw))
            merged[sha]["mbcs"].update(collapse_mbc_ids(mbc_vals_raw))

    return merged


# ---------------------------
# Feature extraction
# ---------------------------
def _build_report_text(sig_tokens: Set[str], ttp_tokens: Set[str], mbc_tokens: Set[str]) -> str:
    return " ".join(sorted(sig_tokens) + sorted(ttp_tokens) + sorted(mbc_tokens))


def extract_cape_features(
    report: Dict[str, Any],
    vt_techniques: Optional[Set[str]] = None,
    vt_mbcs: Optional[Set[str]] = None,
    feature_vocab: Optional[Dict[str, Any]] = None,
    signature_parent_depth: int = DEFAULT_SIGNATURE_PARENT_DEPTH,
) -> Dict[str, Any]:
    """
    Extract only the 3 dynamic parent-token groups:
    - signature parent tokens
    - ATT&CK parent TTP tokens
    - MBC parent tokens
    """
    vt_techniques = vt_techniques or set()
    vt_mbcs = vt_mbcs or set()

    sig_names_raw: Set[str] = set()
    for sig in report.get("signatures", []) or []:
        name = sig.get("name")
        if name:
            sig_names_raw.add(str(name))

    sig_tokens_raw = {f"sig:{normalize_token(x)}" for x in sig_names_raw if normalize_token(x)}
    sig_tokens = {f"sig:{x}" for x in collapse_signature_names(sig_names_raw, parent_depth=signature_parent_depth)}

    ttp_ids_raw: Set[str] = set()
    for item in report.get("ttps", []) or []:
        ttp_ids_raw |= extract_attack_ids(item.get("ttps", []))

    mitre_obj = report.get("mitre_attck") or report.get("mitre_attack") or {}
    if isinstance(mitre_obj, dict):
        for _, entries in mitre_obj.items():
            if not isinstance(entries, list):
                continue
            for entry in entries:
                t_id = entry.get("t_id")
                if t_id:
                    ttp_ids_raw |= extract_attack_ids(t_id)

    ttp_ids_raw |= extract_attack_ids(vt_techniques)
    ttp_tokens_raw = {f"ttp:{x}" for x in sorted(ttp_ids_raw)}
    ttp_tokens = {f"ttp:{x}" for x in collapse_attack_ids(ttp_ids_raw)}

    mbc_ids_raw: Set[str] = set()
    for item in report.get("ttps", []) or []:
        mbc_ids_raw |= extract_mbc_ids(item.get("mbcs", []))
    mbc_ids_raw |= extract_mbc_ids(vt_mbcs)
    mbc_tokens_raw = {f"mbc:{x}" for x in sorted(mbc_ids_raw)}
    mbc_tokens = {f"mbc:{x}" for x in collapse_mbc_ids(mbc_ids_raw)}

    feats: Dict[str, Any] = {
        "sig_tokens_raw": sig_tokens_raw,
        "sig_tokens": sig_tokens,
        "ttp_tokens_raw": ttp_tokens_raw,
        "ttp_tokens": ttp_tokens,
        "mbc_tokens_raw": mbc_tokens_raw,
        "mbc_tokens": mbc_tokens,
    }

    if feature_vocab is not None:
        feats = apply_feature_vocab_to_feature_dict(feats, feature_vocab)
    else:
        feats["report_text"] = _build_report_text(sig_tokens, ttp_tokens, mbc_tokens)
        feats["num_signatures_raw"] = len(sig_tokens_raw)
        feats["num_signatures"] = len(sig_tokens)
        feats["num_ttp_raw"] = len(ttp_tokens_raw)
        feats["num_ttp"] = len(ttp_tokens)
        feats["num_mbc_raw"] = len(mbc_tokens_raw)
        feats["num_mbc"] = len(mbc_tokens)
        feats["num_total_tokens"] = len(sig_tokens) + len(ttp_tokens) + len(mbc_tokens)

    return feats


# ---------------------------
# Feature vocab helpers
# ---------------------------
def _doc_frequency(series: pd.Series) -> Counter:
    freq: Counter = Counter()
    for value in series.fillna("").tolist():
        freq.update(pipe_to_set(value))
    return freq


def _sort_and_trim_vocab(counter: Counter, min_df: int, max_vocab: int) -> Tuple[Set[str], Dict[str, int]]:
    kept = [(tok, cnt) for tok, cnt in counter.items() if cnt >= max(1, int(min_df))]
    kept.sort(key=lambda item: (-item[1], item[0]))
    if int(max_vocab) > 0:
        kept = kept[: int(max_vocab)]
    vocab = {tok for tok, _ in kept}
    stats = {
        "raw_vocab_size": int(len(counter)),
        "kept_vocab_size": int(len(vocab)),
        "min_df": int(max(1, int(min_df))),
        "max_vocab": int(max_vocab),
    }
    return vocab, stats


def build_feature_vocab(
    samples: pd.DataFrame,
    *,
    fit_split: str = "train",
    min_df_sig: int = 2,
    min_df_ttp: int = 2,
    min_df_mbc: int = 2,
    max_vocab_sig: int = 400,
    max_vocab_ttp: int = 200,
    max_vocab_mbc: int = 200,
) -> Dict[str, Any]:
    if samples is None or samples.empty:
        raise ValueError("Cannot build feature vocab from an empty samples dataframe")

    work = samples.copy()
    if "split" in work.columns and fit_split:
        selected = work[work["split"].astype(str) == str(fit_split)].copy()
        if selected.empty:
            selected = work
    else:
        selected = work

    sig_counter = _doc_frequency(selected.get("sig_tokens", pd.Series(dtype=object)))
    ttp_counter = _doc_frequency(selected.get("ttp_tokens", pd.Series(dtype=object)))
    mbc_counter = _doc_frequency(selected.get("mbc_tokens", pd.Series(dtype=object)))

    sig_vocab, sig_stats = _sort_and_trim_vocab(sig_counter, min_df_sig, max_vocab_sig)
    ttp_vocab, ttp_stats = _sort_and_trim_vocab(ttp_counter, min_df_ttp, max_vocab_ttp)
    mbc_vocab, mbc_stats = _sort_and_trim_vocab(mbc_counter, min_df_mbc, max_vocab_mbc)

    return {
        "fit_split": str(fit_split),
        "sig_tokens": sig_vocab,
        "ttp_tokens": ttp_vocab,
        "mbc_tokens": mbc_vocab,
        "stats": {
            "sig_tokens": sig_stats,
            "ttp_tokens": ttp_stats,
            "mbc_tokens": mbc_stats,
            "num_fit_rows": int(len(selected)),
        },
        "config": {
            "signature_parent_depth": int(DEFAULT_SIGNATURE_PARENT_DEPTH),
            "min_df_sig": int(min_df_sig),
            "min_df_ttp": int(min_df_ttp),
            "min_df_mbc": int(min_df_mbc),
            "max_vocab_sig": int(max_vocab_sig),
            "max_vocab_ttp": int(max_vocab_ttp),
            "max_vocab_mbc": int(max_vocab_mbc),
        },
    }


def save_feature_vocab(vocab: Dict[str, Any], path: str | Path) -> Path:
    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(vocab, out_path)
    return out_path


def load_feature_vocab(path: str | Path | None) -> Dict[str, Any] | None:
    if path is None:
        return None
    in_path = Path(path)
    if not in_path.exists():
        return None
    loaded = joblib.load(in_path)
    if loaded is None:
        return None
    return loaded


def apply_feature_vocab_to_feature_dict(feats: Dict[str, Any], feature_vocab: Dict[str, Any] | None) -> Dict[str, Any]:
    sig_tokens = pipe_to_set(feats.get("sig_tokens", set()))
    ttp_tokens = pipe_to_set(feats.get("ttp_tokens", set()))
    mbc_tokens = pipe_to_set(feats.get("mbc_tokens", set()))

    if feature_vocab is not None:
        sig_tokens &= set(feature_vocab.get("sig_tokens", set()))
        ttp_tokens &= set(feature_vocab.get("ttp_tokens", set()))
        mbc_tokens &= set(feature_vocab.get("mbc_tokens", set()))

    out = dict(feats)
    out["sig_tokens"] = sig_tokens
    out["ttp_tokens"] = ttp_tokens
    out["mbc_tokens"] = mbc_tokens
    out["report_text"] = _build_report_text(sig_tokens, ttp_tokens, mbc_tokens)
    out["num_signatures"] = len(sig_tokens)
    out["num_ttp"] = len(ttp_tokens)
    out["num_mbc"] = len(mbc_tokens)
    out["num_total_tokens"] = len(sig_tokens) + len(ttp_tokens) + len(mbc_tokens)

    if "sig_tokens_raw" in out:
        out["num_signatures_raw"] = len(pipe_to_set(out.get("sig_tokens_raw", set())))
    if "ttp_tokens_raw" in out:
        out["num_ttp_raw"] = len(pipe_to_set(out.get("ttp_tokens_raw", set())))
    if "mbc_tokens_raw" in out:
        out["num_mbc_raw"] = len(pipe_to_set(out.get("mbc_tokens_raw", set())))
    return out


def apply_feature_vocab_to_samples(samples: pd.DataFrame, feature_vocab: Dict[str, Any] | None) -> pd.DataFrame:
    if samples is None or samples.empty:
        return pd.DataFrame(columns=samples.columns if samples is not None else [])

    rows: List[Dict[str, Any]] = []
    for _, row in samples.iterrows():
        feats = apply_feature_vocab_to_feature_dict(
            {
                "sig_tokens": row.get("sig_tokens", ""),
                "ttp_tokens": row.get("ttp_tokens", ""),
                "mbc_tokens": row.get("mbc_tokens", ""),
            },
            feature_vocab=feature_vocab,
        )
        updated = row.to_dict()
        updated["sig_tokens"] = set_to_pipe(feats["sig_tokens"])
        updated["ttp_tokens"] = set_to_pipe(feats["ttp_tokens"])
        updated["mbc_tokens"] = set_to_pipe(feats["mbc_tokens"])
        updated["report_text"] = feats["report_text"]
        updated["num_signatures"] = feats["num_signatures"]
        updated["num_ttp"] = feats["num_ttp"]
        updated["num_mbc"] = feats["num_mbc"]
        updated["num_total_tokens"] = feats["num_total_tokens"]
        rows.append(updated)
    return pd.DataFrame(rows)


# ---------------------------
# Feature summary export
# ---------------------------
def build_feature_overview(samples: pd.DataFrame) -> pd.DataFrame:
    token_cols = [
        ("sig_tokens", "signatures_parent"),
        ("ttp_tokens", "ttp_parent"),
        ("mbc_tokens", "mbc_parent"),
    ]
    rows = []
    total_samples = int(len(samples))
    for col, label in token_cols:
        if col not in samples.columns:
            continue
        sets = samples[col].apply(pipe_to_set)
        unique_tokens = sorted(set().union(*sets.tolist())) if len(sets) else []
        token_counts = sets.apply(len)
        rows.append(
            {
                "feature_group": label,
                "column_name": col,
                "num_samples": total_samples,
                "num_unique_tokens": int(len(unique_tokens)),
                "avg_tokens_per_sample": float(token_counts.mean()) if len(token_counts) else 0.0,
                "max_tokens_per_sample": int(token_counts.max()) if len(token_counts) else 0,
            }
        )
    return pd.DataFrame(rows)


def build_token_frequency_table(samples: pd.DataFrame, token_col: str, token_group: str) -> pd.DataFrame:
    if token_col not in samples.columns or samples.empty:
        return pd.DataFrame(columns=["feature_group", "token", "sample_count", "sample_ratio"])

    token_sets = samples[token_col].apply(pipe_to_set)
    freq: Dict[str, int] = {}
    for values in token_sets:
        for token in values:
            freq[token] = freq.get(token, 0) + 1

    if not freq:
        return pd.DataFrame(columns=["feature_group", "token", "sample_count", "sample_ratio"])

    total_samples = max(1, len(samples))
    rows = [
        {
            "feature_group": token_group,
            "token": token,
            "sample_count": int(count),
            "sample_ratio": float(count / total_samples),
        }
        for token, count in freq.items()
    ]
    out = pd.DataFrame(rows)
    return out.sort_values(["sample_count", "token"], ascending=[False, True], ignore_index=True)


def export_feature_summary_excel(samples: pd.DataFrame, out_xlsx: str | Path) -> Path:
    out_path = Path(out_xlsx)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    sample_cols_preferred = [
        "sample_id",
        "sha256",
        "family",
        "family_raw",
        "malstatus",
        "split",
        "num_signatures",
        "num_ttp",
        "num_mbc",
        "num_total_tokens",
        "sig_tokens",
        "ttp_tokens",
        "mbc_tokens",
        "report_path",
        "report_text",
    ]
    sample_cols = [c for c in sample_cols_preferred if c in samples.columns] + [
        c for c in samples.columns if c not in sample_cols_preferred
    ]

    overview = build_feature_overview(samples)
    sig_freq = build_token_frequency_table(samples, "sig_tokens", "signatures_parent")
    ttp_freq = build_token_frequency_table(samples, "ttp_tokens", "ttp_parent")
    mbc_freq = build_token_frequency_table(samples, "mbc_tokens", "mbc_parent")

    with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
        samples.loc[:, sample_cols].to_excel(writer, sheet_name="sample_features", index=False)
        overview.to_excel(writer, sheet_name="overview", index=False)
        sig_freq.to_excel(writer, sheet_name="sig_parent_freq", index=False)
        ttp_freq.to_excel(writer, sheet_name="ttp_parent_freq", index=False)
        mbc_freq.to_excel(writer, sheet_name="mbc_parent_freq", index=False)

    return out_path


# ---------------------------
# Similarity helpers
# ---------------------------
def jaccard(a: Set[str], b: Set[str]) -> float:
    union = a | b
    if not union:
        return 0.0
    return len(a & b) / len(union)


def cosine_safe(a: np.ndarray, b: np.ndarray) -> float:
    na = np.linalg.norm(a)
    nb = np.linalg.norm(b)
    if na == 0.0 or nb == 0.0:
        return 0.0
    return float(np.dot(a, b) / (na * nb))


def make_pair_features(q: pd.Series, c: pd.Series, emb_cols: Sequence[str]) -> Dict[str, float]:
    q_sig = pipe_to_set(q.get("sig_tokens", ""))
    c_sig = pipe_to_set(c.get("sig_tokens", ""))

    q_ttp = pipe_to_set(q.get("ttp_tokens", ""))
    c_ttp = pipe_to_set(c.get("ttp_tokens", ""))

    q_mbc = pipe_to_set(q.get("mbc_tokens", ""))
    c_mbc = pipe_to_set(c.get("mbc_tokens", ""))

    q_all = q_sig | q_ttp | q_mbc
    c_all = c_sig | c_ttp | c_mbc

    q_emb = np.asarray([q[col] for col in emb_cols], dtype=float)
    c_emb = np.asarray([c[col] for col in emb_cols], dtype=float)

    return {
        "j_sig": jaccard(q_sig, c_sig),
        "j_ttp": jaccard(q_ttp, c_ttp),
        "j_mbc": jaccard(q_mbc, c_mbc),
        "j_all": jaccard(q_all, c_all),
        "emb_cos": cosine_safe(q_emb, c_emb),
        "overlap_sig_count": float(len(q_sig & c_sig)),
        "overlap_ttp_count": float(len(q_ttp & c_ttp)),
        "overlap_mbc_count": float(len(q_mbc & c_mbc)),
        "overlap_total_count": float(len(q_all & c_all)),
        "abs_delta_num_signatures": abs(float(q.get("num_signatures", 0.0)) - float(c.get("num_signatures", 0.0))),
        "abs_delta_num_ttp": abs(float(q.get("num_ttp", 0.0)) - float(c.get("num_ttp", 0.0))),
        "abs_delta_num_mbc": abs(float(q.get("num_mbc", 0.0)) - float(c.get("num_mbc", 0.0))),
        "abs_delta_total_tokens": abs(float(q.get("num_total_tokens", 0.0)) - float(c.get("num_total_tokens", 0.0))),
    }


def baseline_score(q: pd.Series, c: pd.Series, emb_cols: Sequence[str]) -> float:
    feats = make_pair_features(q, c, emb_cols)
    return (
        0.30 * feats["j_sig"]
        + 0.30 * feats["j_ttp"]
        + 0.20 * feats["j_mbc"]
        + 0.10 * feats["j_all"]
        + 0.10 * feats["emb_cos"]
    )


def reciprocal_rank(relevances: List[int]) -> float:
    for idx, rel in enumerate(relevances, start=1):
        if rel:
            return 1.0 / idx
    return 0.0


# ---------------------------
# Query-time VT helpers
# ---------------------------
def aggregate_vt_workbook_features(path: Optional[str | Path]) -> Dict[str, Set[str]]:
    if path is None:
        return {"ttps": set(), "mbcs": set()}

    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"VT Excel not found: {path}")

    all_sheets = pd.read_excel(path, sheet_name=None, dtype=str)
    ttps_raw: Set[str] = set()
    mbcs_raw: Set[str] = set()

    for _, df in all_sheets.items():
        if df is None or df.empty:
            continue

        df = df.copy()
        df.columns = [str(c).strip() for c in df.columns]

        ttp_col = find_best_column(df.columns, ["technique id", "techniqueid", "ttp", "attack", "mitre"])
        mbc_col = find_best_column(df.columns, ["mbc", "mbcs"])

        if ttp_col is not None:
            for value in df[ttp_col].dropna().tolist():
                ttps_raw |= extract_attack_ids(value)

        if mbc_col is not None:
            for value in df[mbc_col].dropna().tolist():
                mbcs_raw |= extract_mbc_ids(value)

        for _, row in df.iterrows():
            row_text = " ".join("" if row.get(col) is None else str(row.get(col)) for col in df.columns)
            ttps_raw |= extract_attack_ids(row_text)
            mbcs_raw |= extract_mbc_ids(row_text)

    return {"ttps": collapse_attack_ids(ttps_raw), "mbcs": collapse_mbc_ids(mbcs_raw)}


def resolve_query_vt_features(path: Optional[str | Path], query_sha256: str = "") -> Dict[str, Any]:
    empty = {"ttps": set(), "mbcs": set(), "source_mode": "none"}
    if path is None:
        return empty

    vt_map = read_vt_excel(path)
    query_sha256 = extract_sha256(query_sha256)

    if query_sha256 and query_sha256 in vt_map:
        return {
            "ttps": set(vt_map[query_sha256].get("ttps", set())),
            "mbcs": set(vt_map[query_sha256].get("mbcs", set())),
            "source_mode": "matched_sha256",
        }

    agg = aggregate_vt_workbook_features(path)
    return {
        "ttps": set(agg.get("ttps", set())),
        "mbcs": set(agg.get("mbcs", set())),
        "source_mode": "aggregated_workbook",
    }
