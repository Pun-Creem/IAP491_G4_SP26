from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from utils import (
    apply_feature_vocab_to_feature_dict,
    extract_cape_features,
    extract_sha256,
    get_logger_log_path,
    load_feature_vocab,
    load_json,
    log_exception,
    resolve_query_vt_features,
    set_to_pipe,
    setup_logger,
)


SCRIPT_NAME = Path(__file__).stem


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Extract reduced parent-only dynamic-core features (signatures, TTPs, MBCs) for one new CAPE report."
    )
    parser.add_argument("--query-report", required=True, help="Path to the CAPE JSON report of the new malware sample")
    parser.add_argument("--vt-xlsx", default=None, help="Optional VT Excel for the query sample")
    parser.add_argument(
        "--feature-vocab-path",
        default="models/feature_vocab.joblib",
        help="Optional parent-token vocab file for pruning the new sample the same way as training.",
    )
    parser.add_argument("--out-csv", default=None, help="Optional one-row CSV output")
    parser.add_argument("--out-json", default=None, help="Optional JSON output")
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        report = load_json(args.query_report)
        sha256 = extract_sha256(((report.get("target", {}) or {}).get("file", {}) or {}).get("sha256"))
        vt_entry = resolve_query_vt_features(args.vt_xlsx, sha256) if args.vt_xlsx else {"ttps": set(), "mbcs": set(), "source_mode": "none"}

        feats = extract_cape_features(
            report,
            vt_techniques=vt_entry.get("ttps", set()),
            vt_mbcs=vt_entry.get("mbcs", set()),
        )

        feature_vocab = None
        if args.feature_vocab_path:
            feature_vocab = load_feature_vocab(args.feature_vocab_path)
        feats = apply_feature_vocab_to_feature_dict(feats, feature_vocab)

        row = {
            "sample_id": sha256 if sha256 else Path(args.query_report).stem,
            "sha256": sha256,
            "report_path": args.query_report,
            "vt_source_mode": vt_entry.get("source_mode", "none"),
            "sig_tokens": set_to_pipe(feats["sig_tokens"]),
            "ttp_tokens": set_to_pipe(feats["ttp_tokens"]),
            "mbc_tokens": set_to_pipe(feats["mbc_tokens"]),
            "num_signatures": feats["num_signatures"],
            "num_ttp": feats["num_ttp"],
            "num_mbc": feats["num_mbc"],
            "num_total_tokens": feats["num_total_tokens"],
            "report_text": feats["report_text"],
        }

        df = pd.DataFrame([row])
        logger.info(
            "Extracted query features | sha256=%s sig=%d ttp=%d mbc=%d total=%d",
            sha256,
            int(feats["num_signatures"]),
            int(feats["num_ttp"]),
            int(feats["num_mbc"]),
            int(feats["num_total_tokens"]),
        )

        print(df.to_string(index=False))

        if args.out_csv:
            out_csv = Path(args.out_csv)
            out_csv.parent.mkdir(parents=True, exist_ok=True)
            df.to_csv(out_csv, index=False)
            logger.info("Saved CSV: %s", out_csv)
            print(f"\nSaved CSV: {out_csv}")

        if args.out_json:
            out_json = Path(args.out_json)
            out_json.parent.mkdir(parents=True, exist_ok=True)
            payload = row | {
                "sig_token_list": sorted(feats["sig_tokens"]),
                "ttp_token_list": sorted(feats["ttp_tokens"]),
                "mbc_token_list": sorted(feats["mbc_tokens"]),
            }
            out_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
            logger.info("Saved JSON: %s", out_json)
            print(f"Saved JSON: {out_json}")

        logger.info("FINISH %s", SCRIPT_NAME)
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
