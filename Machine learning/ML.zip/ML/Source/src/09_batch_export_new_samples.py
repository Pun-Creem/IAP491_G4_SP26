from __future__ import annotations

import argparse
from pathlib import Path
from typing import Iterable

import joblib
import pandas as pd
from tqdm import tqdm

from inference_utils import build_query_row, make_safe_stem, score_query_against_gallery
from utils import get_logger_log_path, log_exception, setup_logger


MODEL_TO_FILE = {
    "logistic": "similarity_model_logistic.joblib",
    "xgboost": "similarity_model_xgboost.joblib",
    "random_forest": "similarity_model_random_forest.joblib",
}

MODEL_TO_FOLDER = {
    "logistic": "report_logistic",
    "xgboost": "report_xgboost",
    "random_forest": "report_random_forest",
}

SCRIPT_NAME = Path(__file__).stem


def iter_report_files(reports_dir: Path, glob_pattern: str) -> list[Path]:
    files = sorted(reports_dir.glob(glob_pattern))
    return [p for p in files if p.is_file()]


def load_gallery(samples_path: Path, gallery_splits: Iterable[str]) -> pd.DataFrame:
    gallery = pd.read_csv(samples_path)
    gallery = gallery[gallery["split"].isin(list(gallery_splits))].copy().reset_index(drop=True)
    if gallery.empty:
        raise ValueError(f"Gallery is empty for splits={list(gallery_splits)}")
    return gallery


def export_one_model_for_all_queries(
    report_paths: list[Path],
    vt_xlsx: str | None,
    gallery: pd.DataFrame,
    emb_cols: list[str],
    encoder_bundle: dict,
    model_bundle: dict,
    model_name: str,
    out_dir: Path,
    prefilter_topn: int,
    topk: int,
    logger,
) -> pd.DataFrame:
    out_dir.mkdir(parents=True, exist_ok=True)
    summary_rows: list[dict] = []

    for report_path in tqdm(report_paths, desc=f"Exporting {model_name}", unit="file"):
        try:
            query = build_query_row(str(report_path), encoder_bundle, vt_xlsx)
            ranked = score_query_against_gallery(
                query=query,
                gallery=gallery,
                emb_cols=emb_cols,
                model_bundle=model_bundle,
                prefilter_topn=prefilter_topn,
                topk=topk,
            )

            compact = ranked.loc[:, ["candidate_sha256", "similarity_score"]].copy()
            compact["candidate_sha256"] = compact["candidate_sha256"].fillna("").astype(str)
            compact["similarity_score"] = compact["similarity_score"].astype(float)
            compact = compact.rename(columns={"candidate_sha256": "sha256"})
            compact = compact.loc[:, ["sha256", "similarity_score"]]

            query_sha256 = str(query.get("sha256", "") or "")
            file_stem = make_safe_stem(query_sha256 if query_sha256 else report_path.stem, fallback=report_path.stem)
            out_path = out_dir / f"{file_stem}.csv"
            compact.to_csv(out_path, index=False)

            summary_rows.append(
                {
                    "query_report": str(report_path),
                    "query_sha256": query_sha256,
                    "rows_written": int(len(compact)),
                    "top_sha256": str(compact.iloc[0]["sha256"]) if not compact.empty else "",
                    "top_similarity_score": float(compact.iloc[0]["similarity_score"]) if not compact.empty else None,
                    "output_csv": str(out_path),
                }
            )
        except Exception as exc:
            log_exception(logger, f"Failed to export query={report_path} model={model_name}", exc)
            summary_rows.append(
                {
                    "query_report": str(report_path),
                    "query_sha256": "",
                    "rows_written": 0,
                    "top_sha256": "",
                    "top_similarity_score": None,
                    "output_csv": "",
                }
            )

    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(out_dir / "_summary.csv", index=False)
    return summary_df


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Batch-export similarity CSVs for many query CAPE JSON reports across trained models."
    )
    parser.add_argument("--reports-dir", required=True, help="Folder containing query CAPE JSON reports")
    parser.add_argument("--vt-xlsx", required=False, default=None, help="VT workbook containing sha256 / ttps / mbcs for the query samples")
    parser.add_argument("--samples-path", default="data/processed/samples_emb.csv", help="Encoded gallery samples CSV")
    parser.add_argument("--encoder-path", default="models/text_encoder.joblib", help="Text encoder bundle")
    parser.add_argument("--models-dir", default="models", help="Directory containing trained similarity models")
    parser.add_argument("--out-dir", default="report_malware", help="Root output directory")
    parser.add_argument("--glob", default="*_report.json", help="Glob pattern for query reports")
    parser.add_argument("--gallery-splits", nargs="+", default=["train", "val"], help="Gallery splits to use")
    parser.add_argument("--prefilter-topn", type=int, default=50, help="Baseline prefilter before ML rerank")
    parser.add_argument("--topk", type=int, default=5, help="Rows to keep in each output CSV")
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        reports_dir = Path(args.reports_dir)
        samples_path = Path(args.samples_path)
        encoder_path = Path(args.encoder_path)
        models_dir = Path(args.models_dir)
        out_root = Path(args.out_dir)

        if not reports_dir.exists() or not reports_dir.is_dir():
            raise FileNotFoundError(f"Reports directory not found: {reports_dir}")
        if not samples_path.exists():
            raise FileNotFoundError(f"Missing samples file: {samples_path}")
        if not encoder_path.exists():
            raise FileNotFoundError(f"Missing encoder file: {encoder_path}")
        if not models_dir.exists():
            raise FileNotFoundError(f"Missing models directory: {models_dir}")

        report_paths = iter_report_files(reports_dir, args.glob)
        if not report_paths:
            raise FileNotFoundError(f"No query reports found in {reports_dir} with pattern {args.glob}")

        gallery = load_gallery(samples_path, args.gallery_splits)
        encoder_bundle = joblib.load(encoder_path)
        emb_cols = list(encoder_bundle["emb_cols"])

        out_root.mkdir(parents=True, exist_ok=True)
        master_rows: list[dict] = []

        for model_name, model_file in MODEL_TO_FILE.items():
            model_path = models_dir / model_file
            if not model_path.exists():
                logger.warning("Missing model file, skipped: %s", model_path)
                continue

            model_bundle = joblib.load(model_path)
            model_out_dir = out_root / MODEL_TO_FOLDER[model_name]

            summary_df = export_one_model_for_all_queries(
                report_paths=report_paths,
                vt_xlsx=args.vt_xlsx,
                gallery=gallery,
                emb_cols=emb_cols,
                encoder_bundle=encoder_bundle,
                model_bundle=model_bundle,
                model_name=model_name,
                out_dir=model_out_dir,
                prefilter_topn=args.prefilter_topn,
                topk=args.topk,
                logger=logger,
            )

            master_rows.append(
                {
                    "model_name": model_name,
                    "output_folder": str(model_out_dir),
                    "query_files_processed": int(len(summary_df)),
                    "csv_created": int((summary_df["output_csv"].fillna("") != "").sum()) if not summary_df.empty else 0,
                }
            )
            logger.info("Finished model=%s | processed=%d", model_name, len(summary_df))

        master_df = pd.DataFrame(master_rows)
        master_path = out_root / "_master_summary.csv"
        master_df.to_csv(master_path, index=False)

        logger.info("Saved master summary: %s", master_path)
        logger.info("Query reports processed: %d", len(report_paths))
        logger.info("Gallery size: %d", len(gallery))
        logger.info("FINISH %s", SCRIPT_NAME)

        print("\nDone.")
        print(f"Query reports processed: {len(report_paths)}")
        print(f"Gallery size: {len(gallery)}")
        print(f"Output root: {out_root}")
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
