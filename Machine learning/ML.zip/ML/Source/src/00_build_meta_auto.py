from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from tqdm import tqdm

from utils import (
    choose_family,
    extract_sha256,
    get_logger_log_path,
    load_json,
    log_exception,
    setup_logger,
)


SCRIPT_NAME = Path(__file__).stem


def normalize_status(value: object) -> str:
    if value is None:
        return ""
    s = str(value).strip().lower()
    if not s:
        return ""
    mapping = {
        "malicious": "malicious",
        "suspicious": "suspicious",
        "clean": "clean",
        "benign": "benign",
        "failed": "failed",
        "error": "error",
    }
    return mapping.get(s, s)


def safe_malscore(value: Any) -> float:
    try:
        if value is None or str(value).strip() == "":
            return 0.0
        return float(value)
    except Exception:
        return 0.0


def build_error_row(path: Path, error: Exception) -> dict:
    return {
        "sample_id": path.stem,
        "sha256": "",
        "family": "",
        "family_raw": "",
        "malstatus": "",
        "malscore": 0.0,
        "report_path": str(path),
        "scan_status": f"json_error:{error}",
    }


def build_row_from_report(path: Path, report: dict, allowed_status: set[str], keep_all_status: bool) -> dict:
    target_file = (report.get("target", {}) or {}).get("file", {}) or {}
    sha256 = extract_sha256(target_file.get("sha256") or "")
    family, family_raw = choose_family(report)
    malstatus = normalize_status(report.get("malstatus", ""))

    scan_status = "ok"
    if not keep_all_status and malstatus not in allowed_status:
        scan_status = f"filtered_malstatus:{malstatus or 'empty'}"

    return {
        "sample_id": sha256 if sha256 else path.stem,
        "sha256": sha256,
        "family": family if family is not None else "",
        "family_raw": family_raw if family_raw is not None else "",
        "malstatus": malstatus,
        "malscore": safe_malscore(report.get("malscore", 0)),
        "report_path": str(path),
        "scan_status": scan_status,
    }


def assign_global_splits(df: pd.DataFrame, train_ratio: float = 0.7, val_ratio: float = 0.15, random_state: int = 42) -> pd.DataFrame:
    if df.empty:
        out = df.copy()
        out["split"] = pd.Series(dtype="object")
        return out

    if train_ratio <= 0 or val_ratio < 0 or train_ratio + val_ratio >= 1:
        raise ValueError("Require: train_ratio > 0, val_ratio >= 0, and train_ratio + val_ratio < 1")

    n = len(df)
    rng = np.random.default_rng(random_state)
    idx = np.arange(n)
    rng.shuffle(idx)

    n_train = max(1, int(round(train_ratio * n)))
    n_val = int(round(val_ratio * n))
    n_test = n - n_train - n_val

    if n_test < 1:
        n_test = 1
        if n_val > 0:
            n_val -= 1
        else:
            n_train = max(1, n_train - 1)

    while n_train + n_val + n_test > n:
        if n_val > 0:
            n_val -= 1
        elif n_test > 1:
            n_test -= 1
        else:
            n_train -= 1

    while n_train + n_val + n_test < n:
        n_train += 1

    splits = np.empty(n, dtype=object)
    splits[idx[:n_train]] = "train"
    splits[idx[n_train:n_train + n_val]] = "val"
    splits[idx[n_train + n_val:]] = "test"

    out = df.copy().reset_index(drop=True)
    out["split"] = splits
    return out


def build_family_stats(split_meta: pd.DataFrame) -> pd.DataFrame:
    if split_meta.empty or "family" not in split_meta.columns or "split" not in split_meta.columns:
        return pd.DataFrame(columns=["family", "train", "val", "test"])

    work = split_meta.copy()
    work["family"] = work["family"].fillna("").astype(str)
    work.loc[work["family"].str.strip() == "", "family"] = "__missing_family__"

    fam_stats = work.groupby(["family", "split"]).size().unstack(fill_value=0).reset_index()
    for col in ["train", "val", "test"]:
        if col not in fam_stats.columns:
            fam_stats[col] = 0

    fam_stats = fam_stats[["family", "train", "val", "test"]]
    return fam_stats.sort_values(
        by=["train", "val", "test", "family"],
        ascending=[False, False, False, True],
        ignore_index=True,
    )


def build_malstatus_stats(split_meta: pd.DataFrame) -> pd.DataFrame:
    if split_meta.empty or "malstatus" not in split_meta.columns or "split" not in split_meta.columns:
        return pd.DataFrame(columns=["malstatus", "train", "val", "test"])

    work = split_meta.copy()
    work["malstatus"] = work["malstatus"].fillna("").astype(str)
    work.loc[work["malstatus"].str.strip() == "", "malstatus"] = "__empty__"

    status_stats = work.groupby(["malstatus", "split"]).size().unstack(fill_value=0).reset_index()
    for col in ["train", "val", "test"]:
        if col not in status_stats.columns:
            status_stats[col] = 0

    status_stats = status_stats[["malstatus", "train", "val", "test"]]
    return status_stats.sort_values(
        by=["train", "val", "test", "malstatus"],
        ascending=[False, False, False, True],
        ignore_index=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Scan CAPE JSON reports and build metadata CSV while keeping all usable samples."
    )
    parser.add_argument("--reports-dir", required=True, help="Folder containing CAPE JSON reports")
    parser.add_argument("--glob", default="*_report.json", help="Glob pattern for report files")
    parser.add_argument("--out-meta", default="data/raw/meta_auto.csv", help="Output CSV for kept metadata rows")
    parser.add_argument("--out-dropped", default="data/raw/meta_dropped.csv", help="Output CSV for dropped rows")
    parser.add_argument(
        "--allowed-malstatus",
        nargs="*",
        default=[],
        help="Statuses to keep before split. Default keeps ALL statuses.",
    )
    parser.add_argument("--train-ratio", type=float, default=0.7, help="Global train split ratio")
    parser.add_argument("--val-ratio", type=float, default=0.15, help="Global val split ratio")
    parser.add_argument("--random-state", type=int, default=42, help="Random seed for global split")
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        reports_dir = Path(args.reports_dir)
        if not reports_dir.exists():
            raise FileNotFoundError(f"Reports dir not found: {reports_dir}")
        if not reports_dir.is_dir():
            raise NotADirectoryError(f"Reports path is not a directory: {reports_dir}")

        json_paths = sorted(reports_dir.glob(args.glob))
        if not json_paths:
            raise FileNotFoundError(f"No JSON files found in {reports_dir} with pattern {args.glob}")

        allowed_status = {
            normalize_status(x)
            for x in (args.allowed_malstatus or [])
            if str(x).strip()
        }
        keep_all_status = len(allowed_status) == 0
        logger.info("Found %d reports | allowed_status=%s", len(json_paths), sorted(allowed_status) if allowed_status else "ALL")

        rows: list[dict] = []
        error_count = 0

        for path in tqdm(json_paths, desc="Scanning CAPE reports"):
            try:
                report = load_json(path)
                if not isinstance(report, dict):
                    raise ValueError("Loaded JSON is not a dictionary/object")
            except Exception as exc:
                error_count += 1
                log_exception(logger, f"Failed to load JSON report={path}", exc)
                rows.append(build_error_row(path, exc))
                continue

            try:
                row = build_row_from_report(path, report, allowed_status, keep_all_status)
            except Exception as exc:
                error_count += 1
                log_exception(logger, f"Failed to parse report metadata report={path}", exc)
                row = {
                    "sample_id": path.stem,
                    "sha256": "",
                    "family": "",
                    "family_raw": "",
                    "malstatus": "",
                    "malscore": 0.0,
                    "report_path": str(path),
                    "scan_status": f"parse_error:{exc}",
                }

            rows.append(row)

        meta = pd.DataFrame(rows)
        required_cols = [
            "sample_id",
            "sha256",
            "family",
            "family_raw",
            "malstatus",
            "malscore",
            "report_path",
            "scan_status",
        ]
        for col in required_cols:
            if col not in meta.columns:
                meta[col] = ""

        meta = meta[required_cols].copy()
        meta = meta.drop_duplicates(subset=["sample_id"], keep="first").reset_index(drop=True)

        ok_meta = meta[meta["scan_status"] == "ok"].copy()
        split_meta = assign_global_splits(
            ok_meta,
            train_ratio=args.train_ratio,
            val_ratio=args.val_ratio,
            random_state=args.random_state,
        )

        dropped = meta[meta["scan_status"] != "ok"].copy()
        if not dropped.empty:
            dropped["drop_reason"] = dropped["scan_status"]

        out_meta = Path(args.out_meta)
        out_dropped = Path(args.out_dropped)
        out_meta.parent.mkdir(parents=True, exist_ok=True)
        out_dropped.parent.mkdir(parents=True, exist_ok=True)

        split_meta.to_csv(out_meta, index=False)
        dropped.to_csv(out_dropped, index=False)

        fam_stats = build_family_stats(split_meta)
        fam_stats_path = out_meta.parent / "family_split_stats.csv"
        fam_stats.to_csv(fam_stats_path, index=False)

        status_stats = build_malstatus_stats(split_meta)
        status_stats_path = out_meta.parent / "malstatus_split_stats.csv"
        status_stats.to_csv(status_stats_path, index=False)

        logger.info("Saved meta: %s", out_meta)
        logger.info("Saved dropped rows: %s", out_dropped)
        logger.info("Saved family stats: %s", fam_stats_path)
        logger.info("Saved malstatus stats: %s", status_stats_path)
        logger.info("Total JSON scanned: %d", len(meta))
        logger.info("Usable rows kept: %d", len(split_meta))
        logger.info("Dropped rows: %d", len(dropped))
        logger.info("JSON/parse errors: %d", error_count)
        logger.info("FINISH %s", SCRIPT_NAME)

        print(f"Saved meta: {out_meta}")
        print(f"Saved dropped rows: {out_dropped}")
        print(f"Saved family stats: {fam_stats_path}")
        print(f"Saved malstatus stats: {status_stats_path}")
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
