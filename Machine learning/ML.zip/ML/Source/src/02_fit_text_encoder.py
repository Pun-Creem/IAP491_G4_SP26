from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer

from utils import get_logger_log_path, load_feature_vocab, log_exception, setup_logger


SCRIPT_NAME = Path(__file__).stem


def fit_tfidf(
    train_texts: list[str],
    *,
    max_features: int,
    min_df: int,
    max_df: float,
    ngram_max: int,
):
    tfidf = TfidfVectorizer(
        tokenizer=str.split,
        preprocessor=None,
        token_pattern=None,
        lowercase=False,
        max_features=None if int(max_features) <= 0 else int(max_features),
        min_df=max(1, int(min_df)),
        max_df=float(max_df),
        ngram_range=(1, max(1, int(ngram_max))),
        sublinear_tf=True,
    )
    X_train = tfidf.fit_transform(train_texts)
    if X_train.shape[1] == 0:
        raise ValueError("TF-IDF vocabulary is empty after fitting.")
    return tfidf, X_train


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Fit a compact parent-token TF-IDF + SVD encoder on the reduced dynamic-core vocabulary."
    )
    parser.add_argument("--samples-path", default="data/processed/samples.csv")
    parser.add_argument("--out-samples", default="data/processed/samples_emb.csv")
    parser.add_argument("--out-model", default="models/text_encoder.joblib")
    parser.add_argument("--feature-vocab-path", default="models/feature_vocab.joblib")
    parser.add_argument("--tfidf-max-features", type=int, default=3000, help="Maximum TF-IDF vocabulary size after pruning")
    parser.add_argument("--tfidf-min-df", type=int, default=1, help="Minimum document frequency for TF-IDF terms")
    parser.add_argument("--tfidf-max-df", type=float, default=1.0, help="Maximum document frequency ratio for TF-IDF terms")
    parser.add_argument("--ngram-max", type=int, default=1, choices=[1, 2], help="Use 1 for unigrams only or 2 to add bigrams")
    parser.add_argument("--svd-dim", type=int, default=32, help="Target SVD embedding dimension")
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        samples_path = Path(args.samples_path)
        out_samples = Path(args.out_samples)
        out_model = Path(args.out_model)
        feature_vocab_path = Path(args.feature_vocab_path) if args.feature_vocab_path else None

        if not samples_path.exists():
            raise FileNotFoundError("Run 01_build_samples_from_cape_vt.py first.")

        df = pd.read_csv(samples_path)
        if "split" not in df.columns:
            raise ValueError("samples.csv is missing 'split'. Re-run 00_build_meta_auto.py and 01_build_samples_from_cape_vt.py.")

        train_mask = df["split"].astype(str).eq("train")
        if int(train_mask.sum()) == 0:
            raise ValueError("No training rows found in samples.csv")

        train_texts = df.loc[train_mask, "report_text"].fillna("").astype(str).tolist()
        all_texts = df["report_text"].fillna("").astype(str).tolist()

        if not any(text.strip() for text in train_texts):
            raise ValueError(
                "All train report_text values are empty. The parent-token pruning is probably too aggressive."
            )

        tfidf, X_train = fit_tfidf(
            train_texts=train_texts,
            max_features=args.tfidf_max_features,
            min_df=args.tfidf_min_df,
            max_df=args.tfidf_max_df,
            ngram_max=args.ngram_max,
        )
        X_all = tfidf.transform(all_texts)

        svd = None
        used_svd = False
        if X_train.shape[0] >= 2 and X_train.shape[1] >= 2 and int(args.svd_dim) > 0:
            max_possible = min(int(args.svd_dim), X_train.shape[1] - 1, X_train.shape[0] - 1)
            if max_possible >= 1:
                svd = TruncatedSVD(n_components=max_possible, random_state=42)
                svd.fit(X_train)
                X_emb = svd.transform(X_all)
                used_svd = True
            else:
                X_emb = X_all.toarray()
        else:
            X_emb = X_all.toarray()

        if X_emb.ndim == 1:
            X_emb = X_emb.reshape(-1, 1)

        emb_cols = [f"e_{i}" for i in range(X_emb.shape[1])]
        for idx, col in enumerate(emb_cols):
            df[col] = X_emb[:, idx]

        feature_vocab = load_feature_vocab(feature_vocab_path) if feature_vocab_path and feature_vocab_path.exists() else None

        out_samples.parent.mkdir(parents=True, exist_ok=True)
        out_model.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(out_samples, index=False)

        joblib.dump(
            {
                "tfidf": tfidf,
                "svd": svd,
                "emb_cols": emb_cols,
                "fit_split": "train_only",
                "num_train_rows": int(train_mask.sum()),
                "num_all_rows": int(len(df)),
                "feature_vocab": feature_vocab,
                "feature_vocab_path": str(feature_vocab_path) if feature_vocab_path else "",
                "tokenizer_mode": "space_split_parent_tokens",
                "tfidf_max_features": None if args.tfidf_max_features <= 0 else int(args.tfidf_max_features),
                "tfidf_min_df": int(max(1, args.tfidf_min_df)),
                "tfidf_max_df": float(args.tfidf_max_df),
                "ngram_max": int(args.ngram_max),
                "used_svd": bool(used_svd),
                "svd_dim_effective": int(X_emb.shape[1]),
            },
            out_model,
        )

        logger.info("Saved encoded samples: %s", out_samples)
        logger.info("Saved encoder: %s", out_model)
        logger.info("TF-IDF vocabulary size: %d", len(tfidf.vocabulary_))
        logger.info("Embedding dimension: %d", len(emb_cols))
        logger.info("Used SVD: %s", used_svd)
        logger.info("FINISH %s", SCRIPT_NAME)

        print(f"Saved encoded samples: {out_samples}")
        print(f"Saved encoder: {out_model}")
        print(f"Embedding dimension: {len(emb_cols)}")
        print(f"TF-IDF vocabulary size: {len(tfidf.vocabulary_)}")
        print(f"TF-IDF/SVD fitted on train rows only: {int(train_mask.sum())}")
        print("Tokenizer mode: space_split_parent_tokens")
        print(f"Used SVD: {used_svd}")
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
