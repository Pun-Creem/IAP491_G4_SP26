from __future__ import annotations

import argparse
from pathlib import Path

import joblib
import pandas as pd

from inference_utils import build_query_row, make_safe_stem, score_query_against_gallery
from utils import get_logger_log_path, log_exception, setup_logger


INPUT_OUTPUT_COLS = ["candidate_sha256", "similarity_score"]
FINAL_OUTPUT_COLS = ["sha256", "similarity_score"]
SCRIPT_NAME = Path(__file__).stem


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Infer top-k similar malware for a new sample using parent-only dynamic-core features."
    )
    parser.add_argument("--query-report", required=True, help="Path to the CAPE JSON report of the query malware sample")
    parser.add_argument("--vt-xlsx", default=None, help="Optional VT Excel for the query sample")
    parser.add_argument("--samples-path", default="data/processed/samples_emb.csv")
    parser.add_argument("--encoder-path", default="models/text_encoder.joblib")
    parser.add_argument("--model-path", required=True)
    parser.add_argument("--prefilter-topn", type=int, default=50, help="Baseline prefilter before ML rerank")
    parser.add_argument("--topk", type=int, default=5)
    parser.add_argument("--gallery-splits", nargs="+", default=["train", "val"])
    parser.add_argument("--out-dir", default=None, help="Optional output directory to save compact top-k CSV")
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        gallery = pd.read_csv(args.samples_path)
        gallery = gallery[gallery["split"].isin(args.gallery_splits)].copy().reset_index(drop=True)
        if gallery.empty:
            raise ValueError(f"Gallery is empty for splits={args.gallery_splits}")

        encoder_bundle = joblib.load(args.encoder_path)
        emb_cols = encoder_bundle["emb_cols"]
        model_bundle = joblib.load(args.model_path)
        query = build_query_row(args.query_report, encoder_bundle, args.vt_xlsx)

        ranked = score_query_against_gallery(
            query,
            gallery,
            emb_cols,
            model_bundle=model_bundle,
            prefilter_topn=args.prefilter_topn,
            topk=args.topk,
        )
        compact = ranked.loc[:, INPUT_OUTPUT_COLS].copy()
        compact["candidate_sha256"] = compact["candidate_sha256"].fillna("").astype(str)
        compact["similarity_score"] = compact["similarity_score"].astype(float)
        compact = compact.rename(columns={"candidate_sha256": "sha256"})
        compact = compact.loc[:, FINAL_OUTPUT_COLS]

        logger.info(
            "Query sha256=%s | gallery_size=%d | returned_rows=%d",
            str(query.get("sha256", "") or ""),
            len(gallery),
            len(compact),
        )

        print(compact.to_string(index=False))

        if args.out_dir:
            out_dir = Path(args.out_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            query_id = query.get("sha256") or Path(args.query_report).stem
            model_name = str(model_bundle.get("model_name", Path(args.model_path).stem))
            out_path = out_dir / f"{make_safe_stem(query_id, fallback='query')}_similarity_{make_safe_stem(model_name)}.csv"
            compact.to_csv(out_path, index=False)
            logger.info("Saved compact CSV: %s", out_path)
            print(f"\nSaved top-{len(compact)} compact CSV: {out_path}")

        logger.info("FINISH %s", SCRIPT_NAME)
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
