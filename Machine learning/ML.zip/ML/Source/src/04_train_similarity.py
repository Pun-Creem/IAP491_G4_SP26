from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from xgboost import XGBClassifier

from utils import get_logger_log_path, log_exception, setup_logger


RANDOM_STATE = 42
SCRIPT_NAME = Path(__file__).stem


def build_logistic() -> Any:
    return make_pipeline(
        StandardScaler(),
        LogisticRegression(
            max_iter=3000,
            class_weight="balanced",
            random_state=RANDOM_STATE,
        ),
    )


def build_xgboost(y: np.ndarray) -> XGBClassifier:
    pos = max(1, int((y == 1).sum()))
    neg = max(1, int((y == 0).sum()))
    scale_pos_weight = neg / pos

    return XGBClassifier(
        n_estimators=300,
        max_depth=4,
        learning_rate=0.03,
        min_child_weight=5,
        reg_alpha=0.1,
        reg_lambda=1.0,
        subsample=0.7,
        colsample_bytree=0.7,
        objective="binary:logistic",
        eval_metric="logloss",
        n_jobs=-1,
        random_state=RANDOM_STATE,
        scale_pos_weight=scale_pos_weight,
    )


def build_random_forest() -> RandomForestClassifier:
    return RandomForestClassifier(
        n_estimators=300,
        max_depth=10,
        min_samples_split=10,
        min_samples_leaf=5,
        class_weight="balanced_subsample",
        n_jobs=-1,
        random_state=RANDOM_STATE,
    )


def get_model(model_name: str, y: np.ndarray) -> Any:
    if model_name == "logistic":
        return build_logistic()
    if model_name == "xgboost":
        return build_xgboost(y)
    if model_name == "random_forest":
        return build_random_forest()
    raise ValueError(f"Unsupported model: {model_name}")


def get_model_params(model: Any) -> dict[str, Any]:
    try:
        params = model.get_params()
    except Exception:
        return {}

    keep_keys = [
        "max_iter",
        "class_weight",
        "n_estimators",
        "max_depth",
        "min_samples_split",
        "min_samples_leaf",
        "learning_rate",
        "min_child_weight",
        "reg_alpha",
        "reg_lambda",
        "subsample",
        "colsample_bytree",
        "scale_pos_weight",
        "random_state",
    ]
    return {k: params[k] for k in keep_keys if k in params}


def evaluate_binary(model: Any, X: np.ndarray, y: np.ndarray) -> dict[str, float | None]:
    if len(y) == 0:
        return {"roc_auc": None, "avg_precision": None}

    proba = model.predict_proba(X)[:, 1]
    out: dict[str, float | None] = {}
    try:
        out["roc_auc"] = float(roc_auc_score(y, proba))
    except Exception:
        out["roc_auc"] = None
    try:
        out["avg_precision"] = float(average_precision_score(y, proba))
    except Exception:
        out["avg_precision"] = None
    return out


def safe_gap(train_value: float | None, val_value: float | None) -> float | None:
    if train_value is None or val_value is None:
        return None
    return float(train_value - val_value)


def extract_feature_importance(model: Any, feature_cols: list[str]) -> pd.DataFrame:
    values = None

    if hasattr(model, "named_steps"):
        final_est = list(model.named_steps.values())[-1]
        if hasattr(final_est, "coef_"):
            values = np.ravel(final_est.coef_)

    if values is None and hasattr(model, "feature_importances_"):
        values = np.ravel(model.feature_importances_)

    if values is None:
        return pd.DataFrame(columns=["feature", "importance", "abs_importance"])

    df = pd.DataFrame({"feature": feature_cols, "importance": values})
    df["abs_importance"] = df["importance"].abs()
    return df.sort_values(["abs_importance", "feature"], ascending=[False, True], ignore_index=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Train a pairwise malware similarity model.")
    parser.add_argument("--model", choices=["logistic", "xgboost", "random_forest"], default="logistic")
    parser.add_argument("--train-path", default="data/processed/pairs_train.csv")
    parser.add_argument("--val-path", default="data/processed/pairs_val.csv")
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        train_path = Path(args.train_path)
        val_path = Path(args.val_path)
        out_model = Path(f"models/similarity_model_{args.model}.joblib")
        out_metrics = Path(f"models/train_metrics_{args.model}.json")
        out_importance = Path(f"models/feature_importance_{args.model}.csv")

        if not train_path.exists():
            raise FileNotFoundError("Run 03_build_pairs.py first.")

        train_df = pd.read_csv(train_path)
        val_df = pd.read_csv(val_path) if val_path.exists() and val_path.stat().st_size > 0 else pd.DataFrame()

        drop_cols = {"query_id", "cand_id", "query_family", "cand_family", "label"}
        feature_cols = [c for c in train_df.columns if c not in drop_cols]
        if not feature_cols:
            raise ValueError("No feature columns found in pairs_train.csv")

        X_train = train_df[feature_cols].to_numpy(dtype=float)
        y_train = train_df["label"].to_numpy(dtype=int)

        X_val: np.ndarray | None = None
        y_val: np.ndarray | None = None
        if not val_df.empty:
            X_val = val_df[feature_cols].to_numpy(dtype=float)
            y_val = val_df["label"].to_numpy(dtype=int)

        logger.info(
            "Training data | rows=%d pos=%d neg=%d features=%d",
            len(train_df),
            int((y_train == 1).sum()),
            int((y_train == 0).sum()),
            len(feature_cols),
        )
        if y_val is not None:
            logger.info(
                "Validation data | rows=%d pos=%d neg=%d",
                len(val_df),
                int((y_val == 1).sum()),
                int((y_val == 0).sum()),
            )

        model = get_model(args.model, y_train)

        if args.model == "xgboost" and X_val is not None and y_val is not None and len(y_val) > 0:
            model.fit(X_train, y_train, eval_set=[(X_val, y_val)], verbose=False)
        else:
            model.fit(X_train, y_train)

        metrics: dict[str, Any] = {
            "model_name": args.model,
            "model_params": get_model_params(model),
            "num_train_rows": int(len(train_df)),
            "num_val_rows": int(len(val_df)),
            "num_features": int(len(feature_cols)),
        }
        metrics["train"] = evaluate_binary(model, X_train, y_train)
        metrics["val"] = evaluate_binary(model, X_val, y_val) if X_val is not None and y_val is not None else {"roc_auc": None, "avg_precision": None}
        metrics["generalization_gap"] = {
            "roc_auc_gap": safe_gap(metrics["train"].get("roc_auc"), metrics["val"].get("roc_auc")),
            "avg_precision_gap": safe_gap(metrics["train"].get("avg_precision"), metrics["val"].get("avg_precision")),
        }

        importance_df = extract_feature_importance(model, feature_cols)

        out_model.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump({"model": model, "feature_cols": feature_cols, "model_name": args.model}, out_model)
        out_metrics.write_text(json.dumps(metrics, indent=2), encoding="utf-8")
        importance_df.to_csv(out_importance, index=False)

        logger.info("Saved model: %s", out_model)
        logger.info("Saved metrics: %s", out_metrics)
        logger.info("Saved feature importance: %s", out_importance)
        logger.info("Training metrics: %s", json.dumps(metrics, ensure_ascii=False))
        logger.info("FINISH %s", SCRIPT_NAME)

        print(json.dumps(metrics, indent=2))
        print(f"Saved model: {out_model}")
        print(f"Saved metrics: {out_metrics}")
        print(f"Saved feature importance: {out_importance}")
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
