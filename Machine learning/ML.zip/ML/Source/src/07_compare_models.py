from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from utils import get_logger_log_path, log_exception, setup_logger


SCRIPT_NAME = Path(__file__).stem


def load_metrics(path: Path) -> dict | None:
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare retrieval metrics across trained models.")
    parser.add_argument("--metrics-dir", default="data/processed")
    parser.add_argument("--out-path", default=None, help="Optional output CSV path. Default: <metrics-dir>/model_comparison.csv")
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        metrics_dir = Path(args.metrics_dir)
        rows = []

        for model_name in ["logistic", "xgboost", "random_forest"]:
            path = metrics_dir / f"retrieval_metrics_{model_name}.json"
            payload = load_metrics(path)
            if payload is None:
                logger.info("Metrics file missing, skipped: %s", path)
                continue

            baseline = payload.get("baseline")
            model = payload.get(model_name)
            if baseline:
                rows.append(
                    {
                        "model": "baseline",
                        "hit_at_5": baseline.get("hit_at_5"),
                        "precision_at_5": baseline.get("precision_at_5"),
                        "mrr": baseline.get("mrr"),
                    }
                )
            if model:
                rows.append(
                    {
                        "model": model_name,
                        "hit_at_5": model.get("hit_at_5"),
                        "precision_at_5": model.get("precision_at_5"),
                        "mrr": model.get("mrr"),
                    }
                )

        if not rows:
            logger.info("No metrics found in %s", metrics_dir)
            print("No metrics found. Run evaluation first.")
            print(f"Log file: {get_logger_log_path(logger)}")
            return

        df = pd.DataFrame(rows).drop_duplicates(subset=["model"]).sort_values("mrr", ascending=False)
        out_path = Path(args.out_path) if args.out_path else metrics_dir / "model_comparison.csv"
        out_path.parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(out_path, index=False)

        logger.info("Saved comparison CSV: %s", out_path)
        logger.info("Comparison rows=%d", len(df))
        logger.info("FINISH %s", SCRIPT_NAME)

        print("\nModel comparison:\n")
        print(df.to_string(index=False))
        print(f"\nSaved: {out_path}")
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
