from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from tqdm import tqdm

from utils import baseline_score, get_logger_log_path, log_exception, make_pair_features, setup_logger


RANDOM_STATE = 42
SCRIPT_NAME = Path(__file__).stem


def canonical_pair_key(a: object, b: object) -> tuple[str, str]:
    sa = str(a)
    sb = str(b)
    return (sa, sb) if sa <= sb else (sb, sa)


def build_pairs_for_queries(
    queries: pd.DataFrame,
    gallery: pd.DataFrame,
    emb_cols: list[str],
    *,
    topn_candidates: int,
    hard_negatives: int,
    easy_negatives: int,
    max_positives: int,
    dedupe_symmetric: bool = False,
) -> pd.DataFrame:
    rng = np.random.default_rng(RANDOM_STATE)
    pair_rows: list[dict] = []
    global_seen_unordered: set[tuple[str, str]] = set()

    for _, q in tqdm(queries.iterrows(), total=len(queries), desc="Building pairs"):
        scored = []
        for _, c in gallery.iterrows():
            if q["sample_id"] == c["sample_id"]:
                continue
            s = baseline_score(q, c, emb_cols)
            scored.append((c["sample_id"], s))

        if not scored:
            continue

        cand_df = pd.DataFrame(scored, columns=["sample_id", "baseline_score"])
        cand_df = cand_df.sort_values("baseline_score", ascending=False).head(max(1, int(topn_candidates)))
        candidates = gallery.merge(cand_df, on="sample_id", how="inner")

        positives = candidates[candidates["family"] == q["family"]]
        if len(positives) > int(max_positives) > 0:
            positives = positives.sample(int(max_positives), random_state=RANDOM_STATE)

        hard_negs = candidates[candidates["family"] != q["family"]].head(max(0, int(hard_negatives)))

        easy_pool = gallery[gallery["family"] != q["family"]].copy()
        easy_pool = easy_pool[easy_pool["sample_id"] != q["sample_id"]]
        if not easy_pool.empty and int(easy_negatives) > 0:
            n_easy = min(int(easy_negatives), len(easy_pool))
            easy_negs = easy_pool.sample(n=n_easy, random_state=RANDOM_STATE)
        else:
            easy_negs = easy_pool.head(0)

        selected: list[tuple[pd.Series, int]] = []
        for _, c in positives.iterrows():
            selected.append((c, 1))
        for _, c in hard_negs.iterrows():
            selected.append((c, 0))
        for _, c in easy_negs.iterrows():
            selected.append((c, 0))

        seen_ordered: set[tuple[str, str]] = set()
        for c, label in selected:
            ordered_pair_key = (str(q["sample_id"]), str(c["sample_id"]))
            if ordered_pair_key in seen_ordered:
                continue
            seen_ordered.add(ordered_pair_key)

            if dedupe_symmetric:
                unordered_pair_key = canonical_pair_key(q["sample_id"], c["sample_id"])
                if unordered_pair_key in global_seen_unordered:
                    continue
                global_seen_unordered.add(unordered_pair_key)

            feats = make_pair_features(q, c, emb_cols)
            pair_rows.append(
                {
                    "query_id": q["sample_id"],
                    "cand_id": c["sample_id"],
                    "query_family": q["family"],
                    "cand_family": c["family"],
                    "label": label,
                    **feats,
                }
            )

    return pd.DataFrame(pair_rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Build train/val pair features for the malware similarity model.")
    parser.add_argument("--samples-path", default="data/processed/samples_emb.csv")
    parser.add_argument("--out-train", default="data/processed/pairs_train.csv")
    parser.add_argument("--out-val", default="data/processed/pairs_val.csv")
    parser.add_argument("--topn-candidates", type=int, default=50)
    parser.add_argument("--hard-negatives", type=int, default=5)
    parser.add_argument("--easy-negatives", type=int, default=5)
    parser.add_argument("--max-positives", type=int, default=5)
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        samples_path = Path(args.samples_path)
        if not samples_path.exists():
            raise FileNotFoundError("Run 02_fit_text_encoder.py first.")

        df = pd.read_csv(samples_path)
        emb_cols = [c for c in df.columns if c.startswith("e_")]
        if not emb_cols:
            raise ValueError("No embedding columns found. Re-run 02_fit_text_encoder.py")

        train_df = df[df["split"] == "train"].copy().reset_index(drop=True)
        val_df = df[df["split"] == "val"].copy().reset_index(drop=True)
        logger.info("Train rows=%d | Val rows=%d | Emb cols=%d", len(train_df), len(val_df), len(emb_cols))

        pairs_train = build_pairs_for_queries(
            train_df,
            train_df,
            emb_cols,
            topn_candidates=args.topn_candidates,
            hard_negatives=args.hard_negatives,
            easy_negatives=args.easy_negatives,
            max_positives=args.max_positives,
            dedupe_symmetric=True,
        )
        pairs_val = (
            build_pairs_for_queries(
                val_df,
                train_df,
                emb_cols,
                topn_candidates=args.topn_candidates,
                hard_negatives=args.hard_negatives,
                easy_negatives=args.easy_negatives,
                max_positives=args.max_positives,
                dedupe_symmetric=False,
            )
            if not val_df.empty
            else pd.DataFrame()
        )

        train_path = Path(args.out_train)
        val_path = Path(args.out_val)
        train_path.parent.mkdir(parents=True, exist_ok=True)
        val_path.parent.mkdir(parents=True, exist_ok=True)
        pairs_train.to_csv(train_path, index=False)
        pairs_val.to_csv(val_path, index=False)

        logger.info("Saved train pairs: %s | rows=%d", train_path, len(pairs_train))
        logger.info("Saved val pairs: %s | rows=%d", val_path, len(pairs_val))
        logger.info(
            "Train labels | pos=%d neg=%d",
            int((pairs_train.get("label", pd.Series(dtype=int)) == 1).sum()) if not pairs_train.empty else 0,
            int((pairs_train.get("label", pd.Series(dtype=int)) == 0).sum()) if not pairs_train.empty else 0,
        )
        logger.info("FINISH %s", SCRIPT_NAME)

        print(f"Saved: {train_path} ({len(pairs_train)} rows)")
        print(f"Saved: {val_path} ({len(pairs_val)} rows)")
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
