from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import pandas as pd

from inference_utils import build_query_row, make_safe_stem, score_query_against_gallery
from utils import get_logger_log_path, log_exception, setup_logger


DEFAULT_MODELS = ["logistic", "xgboost", "random_forest"]
INPUT_OUTPUT_COLS = ["candidate_sha256", "similarity_score"]
FINAL_OUTPUT_COLS = ["sha256", "similarity_score"]
SCRIPT_NAME = Path(__file__).stem


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Export top-k similarity CSVs for one new sample using parent-only dynamic-core features."
    )
    parser.add_argument("--query-report", required=True, help="Path to the CAPE JSON report of the query malware sample")
    parser.add_argument("--vt-xlsx", default=None, help="Optional VT Excel for the query sample")
    parser.add_argument("--samples-path", default="data/processed/samples_emb.csv")
    parser.add_argument("--encoder-path", default="models/text_encoder.joblib")
    parser.add_argument("--models-dir", default="models")
    parser.add_argument("--out-dir", default="report_similarity")
    parser.add_argument("--models", nargs="+", default=DEFAULT_MODELS)
    parser.add_argument("--prefilter-topn", type=int, default=50)
    parser.add_argument("--topk", type=int, default=5)
    parser.add_argument("--gallery-splits", nargs="+", default=["train", "val"])
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        samples_path = Path(args.samples_path)
        encoder_path = Path(args.encoder_path)
        models_dir = Path(args.models_dir)
        out_dir = Path(args.out_dir)

        if not samples_path.exists():
            raise FileNotFoundError(f"Missing samples file: {samples_path}")
        if not encoder_path.exists():
            raise FileNotFoundError(f"Missing encoder file: {encoder_path}")
        if not models_dir.exists():
            raise FileNotFoundError(f"Missing models directory: {models_dir}")

        gallery = pd.read_csv(samples_path)
        gallery = gallery[gallery["split"].isin(args.gallery_splits)].copy().reset_index(drop=True)
        if gallery.empty:
            raise ValueError(f"Gallery is empty for splits={args.gallery_splits}")

        encoder_bundle = joblib.load(encoder_path)
        emb_cols = encoder_bundle["emb_cols"]
        query = build_query_row(args.query_report, encoder_bundle, args.vt_xlsx)

        query_id = query.get("sha256") or Path(args.query_report).stem
        query_stem = make_safe_stem(query_id, fallback="query")

        out_dir.mkdir(parents=True, exist_ok=True)
        created_files: list[dict[str, object]] = []
        missing_models: list[str] = []

        for model_name in args.models:
            model_path = models_dir / f"similarity_model_{model_name}.joblib"
            if not model_path.exists():
                missing_models.append(model_name)
                logger.warning("Missing model file, skipped: %s", model_path)
                print(f"[WARN] Missing model file, skipped: {model_path}")
                continue

            model_bundle = joblib.load(model_path)
            ranked = score_query_against_gallery(
                query,
                gallery,
                emb_cols,
                model_bundle=model_bundle,
                prefilter_topn=args.prefilter_topn,
                topk=args.topk,
            )
            if ranked.empty:
                logger.warning("No ranking produced for model=%s", model_name)
                print(f"[WARN] No ranking produced for model={model_name}")
                continue

            compact = ranked.loc[:, INPUT_OUTPUT_COLS].copy()
            compact["candidate_sha256"] = compact["candidate_sha256"].fillna("").astype(str)
            compact["similarity_score"] = compact["similarity_score"].astype(float)
            compact = compact.rename(columns={"candidate_sha256": "sha256"})
            compact = compact.loc[:, FINAL_OUTPUT_COLS]

            out_path = out_dir / f"{query_stem}_similarity_{model_name}.csv"
            compact.to_csv(out_path, index=False)
            created_files.append(
                {
                    "model_name": model_name,
                    "rows": int(len(compact)),
                    "top_sha256": str(compact.iloc[0]["sha256"]) if not compact.empty else "",
                    "top_similarity_score": float(compact.iloc[0]["similarity_score"]) if not compact.empty else None,
                    "path": str(out_path),
                }
            )
            logger.info("Saved model export: %s | rows=%d", out_path, len(compact))
            print(f"[OK] Saved top-{len(compact)} compact CSV: {out_path}")

        summary = {
            "query_sha256": str(query.get("sha256", "") or ""),
            "query_report": str(args.query_report),
            "query_vt_source_mode": str(query.get("vt_source_mode", "none") or "none"),
            "gallery_size": int(len(gallery)),
            "prefilter_topn": int(args.prefilter_topn),
            "topk": int(args.topk),
            "output_columns": FINAL_OUTPUT_COLS,
            "created_files": created_files,
            "missing_models": missing_models,
        }
        summary_path = out_dir / f"{query_stem}_summary.json"
        summary_path.write_text(json.dumps(summary, indent=2), encoding="utf-8")

        logger.info("Saved summary: %s", summary_path)
        logger.info("FINISH %s", SCRIPT_NAME)

        print("\nSummary:")
        print(json.dumps(summary, indent=2))
        print(f"Saved summary: {summary_path}")
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
