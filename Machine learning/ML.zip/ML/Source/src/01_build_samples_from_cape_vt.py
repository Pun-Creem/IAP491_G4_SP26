from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd
from tqdm import tqdm

from utils import (
    apply_feature_vocab_to_samples,
    build_feature_vocab,
    export_feature_summary_excel,
    extract_cape_features,
    get_logger_log_path,
    load_json,
    log_exception,
    normalize_sha256,
    read_vt_excel,
    save_feature_vocab,
    set_to_pipe,
    setup_logger,
)


SCRIPT_NAME = Path(__file__).stem


def count_unique_pipe_tokens(series: pd.Series) -> int:
    if series is None or series.empty:
        return 0
    token_sets = series.fillna("").astype(str).map(lambda x: {tok for tok in x.split("|") if tok})
    return len(set().union(*token_sets.tolist())) if len(token_sets) else 0


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Build parent-only dynamic-core malware samples using signatures, TTPs, and MBCs."
    )
    parser.add_argument("--meta-csv", default="data/raw/meta_auto.csv")
    parser.add_argument("--vt-xlsx", default=None, help="Optional VT Excel with sha256 / Technique ID / mbc")
    parser.add_argument("--out-csv", default="data/processed/samples.csv")
    parser.add_argument(
        "--out-xlsx",
        default="data/processed/feature_summary.xlsx",
        help="Excel workbook that summarizes extracted parent features per sample",
    )
    parser.add_argument(
        "--feature-vocab-out",
        default="models/feature_vocab.joblib",
        help="Saved train-split vocabulary used to prune parent tokens consistently for train/infer.",
    )
    parser.add_argument("--min-df-sig", type=int, default=2, help="Minimum train-document frequency for parent signature tokens")
    parser.add_argument("--min-df-ttp", type=int, default=2, help="Minimum train-document frequency for parent TTP tokens")
    parser.add_argument("--min-df-mbc", type=int, default=2, help="Minimum train-document frequency for parent MBC tokens")
    parser.add_argument("--max-vocab-sig", type=int, default=400, help="Maximum kept parent signature tokens; 0 means keep all")
    parser.add_argument("--max-vocab-ttp", type=int, default=200, help="Maximum kept parent TTP tokens; 0 means keep all")
    parser.add_argument("--max-vocab-mbc", type=int, default=200, help="Maximum kept parent MBC tokens; 0 means keep all")
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        meta_path = Path(args.meta_csv)
        if not meta_path.exists():
            raise FileNotFoundError(f"Missing meta CSV: {meta_path}. Run 00_build_meta_auto.py first.")

        meta = pd.read_csv(meta_path)
        required = {"sample_id", "sha256", "family", "report_path", "split"}
        missing = required - set(meta.columns)
        if missing:
            raise ValueError(f"meta CSV missing required columns: {sorted(missing)}")

        vt_map = read_vt_excel(args.vt_xlsx) if args.vt_xlsx else {}
        logger.info("Loaded VT workbook entries: %d", len(vt_map))

        rows: list[dict] = []
        error_count = 0

        for _, row in tqdm(meta.iterrows(), total=len(meta), desc="Extracting parent-only features"):
            try:
                report = load_json(row["report_path"])
                sha256 = normalize_sha256(row.get("sha256", ""))
                vt_entry = vt_map.get(sha256, {"ttps": set(), "mbcs": set()})

                feats = extract_cape_features(
                    report,
                    vt_techniques=vt_entry.get("ttps", set()),
                    vt_mbcs=vt_entry.get("mbcs", set()),
                )

                rows.append(
                    {
                        "sample_id": row["sample_id"],
                        "sha256": sha256,
                        "family": row["family"],
                        "family_raw": row.get("family_raw", row["family"]),
                        "malstatus": row.get("malstatus", report.get("malstatus", "")),
                        "split": row["split"],
                        "report_path": row["report_path"],
                        "sig_tokens": set_to_pipe(feats["sig_tokens"]),
                        "ttp_tokens": set_to_pipe(feats["ttp_tokens"]),
                        "mbc_tokens": set_to_pipe(feats["mbc_tokens"]),
                    }
                )
            except Exception as exc:
                error_count += 1
                log_exception(logger, f"Failed to extract features for report={row.get('report_path', '')}", exc)

        base_samples = pd.DataFrame(rows)
        if base_samples.empty:
            raise ValueError("No samples were extracted. Check reports and VT workbook.")

        feature_vocab = build_feature_vocab(
            base_samples,
            fit_split="train",
            min_df_sig=args.min_df_sig,
            min_df_ttp=args.min_df_ttp,
            min_df_mbc=args.min_df_mbc,
            max_vocab_sig=args.max_vocab_sig,
            max_vocab_ttp=args.max_vocab_ttp,
            max_vocab_mbc=args.max_vocab_mbc,
        )
        vocab_path = save_feature_vocab(feature_vocab, args.feature_vocab_out)

        for group_name in ["sig_tokens", "ttp_tokens", "mbc_tokens"]:
            stats = feature_vocab.get("stats", {}).get(group_name, {})
            logger.info(
                "Feature vocab %s | fit_split=%s raw=%d kept=%d min_df=%d max_vocab=%d",
                group_name,
                feature_vocab.get("fit_split", "train"),
                int(stats.get("raw_vocab_size", 0)),
                int(stats.get("kept_vocab_size", 0)),
                int(stats.get("min_df", 0)),
                int(stats.get("max_vocab", 0)),
            )

        samples = apply_feature_vocab_to_samples(base_samples, feature_vocab)

        out_csv = Path(args.out_csv)
        out_csv.parent.mkdir(parents=True, exist_ok=True)
        samples.to_csv(out_csv, index=False)

        out_xlsx = export_feature_summary_excel(samples, args.out_xlsx)

        logger.info("Saved sample CSV: %s", out_csv)
        logger.info("Saved feature summary Excel: %s", out_xlsx)
        logger.info("Saved feature vocab: %s", vocab_path)
        logger.info("Total samples written: %d", len(samples))
        logger.info("Feature extraction errors: %d", error_count)
        logger.info(
            "Unique kept parent tokens | sig=%d ttp=%d mbc=%d",
            count_unique_pipe_tokens(samples["sig_tokens"]),
            count_unique_pipe_tokens(samples["ttp_tokens"]),
            count_unique_pipe_tokens(samples["mbc_tokens"]),
        )
        logger.info("FINISH %s", SCRIPT_NAME)

        print(f"Saved: {out_csv}")
        print(f"Saved feature summary Excel: {out_xlsx}")
        print(f"Saved feature vocab: {vocab_path}")
        print("\nQuick check:")
        if not samples.empty:
            preview_cols = [
                "sample_id",
                "family",
                "split",
                "num_signatures",
                "num_ttp",
                "num_mbc",
                "num_total_tokens",
            ]
            print(samples[preview_cols].head().to_string(index=False))
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
