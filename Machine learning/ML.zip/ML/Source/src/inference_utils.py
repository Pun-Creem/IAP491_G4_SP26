from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from utils import (
    apply_feature_vocab_to_feature_dict,
    extract_cape_features,
    extract_sha256,
    load_feature_vocab,
    load_json,
    make_pair_features,
    resolve_query_vt_features,
    set_to_pipe,
)


INTERPRETABLE_PAIR_COLS = [
    "j_sig",
    "j_ttp",
    "j_mbc",
    "j_all",
    "emb_cos",
    "overlap_sig_count",
    "overlap_ttp_count",
    "overlap_mbc_count",
    "overlap_total_count",
    "abs_delta_num_signatures",
    "abs_delta_num_ttp",
    "abs_delta_num_mbc",
    "abs_delta_total_tokens",
]


def make_safe_stem(value: Any, fallback: str = "query") -> str:
    s = "" if value is None else str(value).strip()
    if not s:
        s = fallback
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or fallback


def baseline_from_pair_features(feats: dict[str, float]) -> float:
    return (
        0.30 * float(feats.get("j_sig", 0.0))
        + 0.30 * float(feats.get("j_ttp", 0.0))
        + 0.20 * float(feats.get("j_mbc", 0.0))
        + 0.10 * float(feats.get("j_all", 0.0))
        + 0.10 * float(feats.get("emb_cos", 0.0))
    )


def build_query_row(report_path: str, encoder_bundle: dict, vt_xlsx: str | None) -> pd.Series:
    report = load_json(report_path)
    sha256 = extract_sha256(((report.get("target", {}) or {}).get("file", {}) or {}).get("sha256"))

    vt_entry = resolve_query_vt_features(vt_xlsx, sha256) if vt_xlsx else {"ttps": set(), "mbcs": set(), "source_mode": "none"}

    feature_vocab = encoder_bundle.get("feature_vocab")
    if feature_vocab is None:
        feature_vocab_path = encoder_bundle.get("feature_vocab_path")
        if feature_vocab_path:
            feature_vocab = load_feature_vocab(feature_vocab_path)

    feats = extract_cape_features(
        report,
        vt_techniques=vt_entry.get("ttps", set()),
        vt_mbcs=vt_entry.get("mbcs", set()),
    )
    feats = apply_feature_vocab_to_feature_dict(feats, feature_vocab)

    tfidf = encoder_bundle["tfidf"]
    svd = encoder_bundle.get("svd")
    emb_cols = encoder_bundle["emb_cols"]

    X_q = tfidf.transform([feats["report_text"]])
    emb = svd.transform(X_q)[0] if svd is not None else X_q.toarray()[0]

    row = {
        "sample_id": sha256 if sha256 else make_safe_stem(Path(report_path).stem, fallback="query"),
        "sha256": sha256,
        "family": "__unknown__",
        "family_raw": "__unknown__",
        "split": "query",
        "report_path": report_path,
        "vt_source_mode": vt_entry.get("source_mode", "none"),
        "sig_tokens": set_to_pipe(feats["sig_tokens"]),
        "ttp_tokens": set_to_pipe(feats["ttp_tokens"]),
        "mbc_tokens": set_to_pipe(feats["mbc_tokens"]),
        "report_text": feats["report_text"],
        "num_signatures": feats["num_signatures"],
        "num_ttp": feats["num_ttp"],
        "num_mbc": feats["num_mbc"],
        "num_total_tokens": feats["num_total_tokens"],
    }
    for i, col in enumerate(emb_cols):
        row[col] = float(emb[i])

    return pd.Series(row)


def score_query_against_gallery(
    query: pd.Series,
    gallery: pd.DataFrame,
    emb_cols: list[str],
    model_bundle: dict | None = None,
    prefilter_topn: int = 0,
    topk: int = 0,
) -> pd.DataFrame:
    if gallery.empty:
        return pd.DataFrame()

    feature_cols = model_bundle.get("feature_cols", []) if model_bundle is not None else []
    clf = model_bundle.get("model") if model_bundle is not None else None
    model_name = model_bundle.get("model_name", "baseline") if model_bundle is not None else "baseline"

    staged_rows = []
    for _, c in gallery.iterrows():
        feats = make_pair_features(query, c, emb_cols)
        base = baseline_from_pair_features(feats)
        staged_rows.append((c, feats, base))

    if prefilter_topn and prefilter_topn > 0:
        staged_rows.sort(key=lambda x: x[2], reverse=True)
        staged_rows = staged_rows[:prefilter_topn]

    rows = []
    query_sha256 = str(query.get("sha256", "") or "")
    query_sample_id = str(query.get("sample_id", "") or "")
    query_report_path = str(query.get("report_path", "") or "")
    query_vt_source_mode = str(query.get("vt_source_mode", "none") or "none")

    for c, feats, base in staged_rows:
        similarity_score = float(base)
        if clf is not None:
            x = np.asarray([[float(feats.get(col, 0.0)) for col in feature_cols]], dtype=float)
            similarity_score = float(clf.predict_proba(x)[0, 1])

        row = {
            "query_sample_id": query_sample_id,
            "query_sha256": query_sha256,
            "query_report_path": query_report_path,
            "query_vt_source_mode": query_vt_source_mode,
            "model_name": model_name,
            "candidate_sample_id": c.get("sample_id", ""),
            "candidate_sha256": c.get("sha256", c.get("sample_id", "")),
            "candidate_family": c.get("family", ""),
            "candidate_family_raw": c.get("family_raw", c.get("family", "")),
            "candidate_report_path": c.get("report_path", ""),
            "baseline_score": float(base),
            "similarity_score": float(similarity_score),
        }
        for col in INTERPRETABLE_PAIR_COLS:
            row[col] = float(feats.get(col, 0.0))
        rows.append(row)

    ranked = pd.DataFrame(rows)
    if ranked.empty:
        return ranked

    ranked = ranked.sort_values(
        ["similarity_score", "baseline_score", "candidate_sha256"],
        ascending=[False, False, True],
    ).reset_index(drop=True)
    ranked.insert(0, "rank", np.arange(1, len(ranked) + 1, dtype=int))

    if topk and topk > 0:
        ranked = ranked.head(topk).copy()

    return ranked
