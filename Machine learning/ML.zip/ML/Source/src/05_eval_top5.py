from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from tqdm import tqdm

from utils import baseline_score, get_logger_log_path, log_exception, make_pair_features, reciprocal_rank, setup_logger


SCRIPT_NAME = Path(__file__).stem


def eval_one_mode(
    queries: pd.DataFrame,
    gallery: pd.DataFrame,
    emb_cols: list[str],
    model_bundle: dict | None,
    candidate_topn: int,
    mode_name: str,
):
    hits = []
    p5s = []
    mrrs = []
    top5_rows = []

    feature_cols = model_bundle["feature_cols"] if model_bundle is not None else None
    clf = model_bundle["model"] if model_bundle is not None else None

    for _, q in tqdm(queries.iterrows(), total=len(queries), desc=f"Evaluating {mode_name}"):
        scored = []
        for _, c in gallery.iterrows():
            s = baseline_score(q, c, emb_cols)
            scored.append((c["sample_id"], s))
        cand_df = pd.DataFrame(scored, columns=["sample_id", "baseline_score"])
        cand_df = cand_df.sort_values("baseline_score", ascending=False).head(max(1, int(candidate_topn)))
        candidates = gallery.merge(cand_df, on="sample_id", how="inner")

        if model_bundle is None:
            ranked = candidates.sort_values("baseline_score", ascending=False).head(5).copy()
            ranked["final_score"] = ranked["baseline_score"]
        else:
            X = []
            rows = []
            for _, c in candidates.iterrows():
                feats = make_pair_features(q, c, emb_cols)
                X.append([feats.get(col, 0.0) for col in feature_cols])
                rows.append(c)
            X = np.asarray(X, dtype=float)
            scores = clf.predict_proba(X)[:, 1]
            ranked = pd.DataFrame(rows).copy()
            ranked["final_score"] = scores
            ranked["baseline_score"] = candidates["baseline_score"].values
            ranked = ranked.sort_values("final_score", ascending=False).head(5)

        relevances = (ranked["family"] == q["family"]).astype(int).tolist()
        hit5 = int(sum(relevances) > 0)
        denom = max(1, len(ranked))
        p5 = float(sum(relevances) / denom)
        rr = reciprocal_rank(relevances)

        hits.append(hit5)
        p5s.append(p5)
        mrrs.append(rr)

        for rank_idx, (_, row) in enumerate(ranked.iterrows(), start=1):
            top5_rows.append(
                {
                    "mode": mode_name,
                    "query_id": q["sample_id"],
                    "query_family": q["family"],
                    "rank": rank_idx,
                    "cand_id": row["sample_id"],
                    "cand_family": row["family"],
                    "baseline_score": float(row.get("baseline_score", 0.0)),
                    "final_score": float(row["final_score"]),
                    "is_relevant": int(row["family"] == q["family"]),
                }
            )

    metrics = {
        "mode": mode_name,
        "num_queries": int(len(queries)),
        "hit_at_5": float(np.mean(hits)) if hits else 0.0,
        "precision_at_5": float(np.mean(p5s)) if p5s else 0.0,
        "mrr": float(np.mean(mrrs)) if mrrs else 0.0,
    }
    return metrics, pd.DataFrame(top5_rows)


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate top-k retrieval quality on the test split.")
    parser.add_argument("--samples-path", default="data/processed/samples_emb.csv")
    parser.add_argument("--model-path", default="models/similarity_model_logistic.joblib")
    parser.add_argument("--candidate-topn", type=int, default=50)
    parser.add_argument(
        "--log-file",
        default="logs",
        help="Directory or .txt base name for per-run logs. Each run creates its own txt file.",
    )
    args = parser.parse_args()

    logger = setup_logger(SCRIPT_NAME, args.log_file)
    logger.info("Arguments: %s", vars(args))

    try:
        samples_path = Path(args.samples_path)
        model_path = Path(args.model_path)

        if not samples_path.exists():
            raise FileNotFoundError("Run 02_fit_text_encoder.py first.")

        df = pd.read_csv(samples_path)
        emb_cols = [c for c in df.columns if c.startswith("e_")]
        if not emb_cols:
            raise ValueError("No embedding columns found in samples_emb.csv")

        gallery = df[df["split"].isin(["train", "val"])].copy().reset_index(drop=True)
        queries = df[df["split"] == "test"].copy().reset_index(drop=True)
        if queries.empty:
            raise ValueError("No test queries found in samples_emb.csv")

        model_bundle = joblib.load(model_path) if model_path.exists() else None

        baseline_metrics, baseline_top5 = eval_one_mode(queries, gallery, emb_cols, None, args.candidate_topn, "baseline")
        model_name = model_bundle["model_name"] if model_bundle is not None else "none"
        model_metrics, model_top5 = eval_one_mode(queries, gallery, emb_cols, model_bundle, args.candidate_topn, model_name)

        out_metrics = Path(f"data/processed/retrieval_metrics_{model_name}.json")
        out_top5 = Path(f"data/processed/top5_results_{model_name}.csv")
        out_metrics.parent.mkdir(parents=True, exist_ok=True)

        payload = {"baseline": baseline_metrics, model_name: model_metrics}
        out_metrics.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        pd.concat([baseline_top5, model_top5], ignore_index=True).to_csv(out_top5, index=False)

        logger.info("Gallery size=%d | Query size=%d", len(gallery), len(queries))
        logger.info("Saved metrics: %s", out_metrics)
        logger.info("Saved top5 results: %s", out_top5)
        logger.info("Payload: %s", json.dumps(payload, ensure_ascii=False))
        logger.info("FINISH %s", SCRIPT_NAME)

        print(json.dumps(payload, indent=2))
        print(f"Saved metrics: {out_metrics}")
        print(f"Saved top5 results: {out_top5}")
        print(f"Log file: {get_logger_log_path(logger)}")
    except Exception as exc:
        log_exception(logger, f"Unhandled error in {SCRIPT_NAME}", exc)
        print(f"Log file: {get_logger_log_path(logger)}")
        raise


if __name__ == "__main__":
    main()
